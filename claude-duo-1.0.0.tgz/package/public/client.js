const ws = new WebSocket(`ws://${window.location.host}`);

const terminals = {
  a: null,
  b: null
};

const fitAddons = {
  a: null,
  b: null
};

const buffers = {
  a: [],
  b: []
};

let autoPipeline = false;
let lastCompleted = null;
let wsReady = false;

// Initialize terminals
function initTerminal(id, elementId) {
  const term = new Terminal({
    cursorBlink: true,
    fontSize: 14,
    fontFamily: 'Menlo, Monaco, "Courier New", monospace',
    theme: {
      background: '#1e1e1e',
      foreground: '#d4d4d4'
    }
  });

  const fitAddon = new FitAddon.FitAddon();
  term.loadAddon(fitAddon);
  term.open(document.getElementById(elementId));
  fitAddon.fit();

  terminals[id] = term;
  fitAddons[id] = fitAddon;

  // Handle terminal input
  term.onData((data) => {
    // Log key codes for debugging
    const codes = [...data].map(c => c.charCodeAt(0));
    console.log(`Terminal ${id} input:`, data, 'codes:', codes);

    ws.send(JSON.stringify({
      type: 'input',
      id: id,
      data: data
    }));
  });

  // Handle resize
  const resizeObserver = new ResizeObserver(() => {
    fitAddon.fit();
    if (wsReady) {
      ws.send(JSON.stringify({
        type: 'resize',
        id: id,
        cols: term.cols,
        rows: term.rows
      }));
    }
  });
  resizeObserver.observe(document.getElementById(elementId));

  return term;
}

// Initialize both terminals
initTerminal('a', 'terminal-a');
initTerminal('b', 'terminal-b');

// Detect task completion
function detectCompletion(id, data) {
  // Ignore shell startup messages
  if (data.includes('default interactive shell') ||
      data.includes('chsh -s') ||
      data.includes('Welcome to')) {
    return;
  }

  // Claude Code specific completion patterns
  const completionPatterns = [
    /I've completed/i,
    /task is complete/i,
    /All done/i,
    /✓.*complete/i,
    /Successfully/i,
    // More specific prompt patterns (avoid false positives)
    /\n.*[$>❯]\s*$/m  // Prompt at end of line after newline
  ];

  const hasCompletion = completionPatterns.some(pattern => pattern.test(data));

  if (hasCompletion && autoPipeline && lastCompleted !== id) {
    console.log(`Detected completion in ${id}, sending to ${id === 'a' ? 'b' : 'a'}`);
    lastCompleted = id;

    setTimeout(() => {
      const output = extractLastOutput(buffers[id]);
      const targetId = id === 'a' ? 'b' : 'a';

      if (output && output.length > 20) { // Minimum length check
        console.log(`Auto-sending ${id} → ${targetId}:`, output.substring(0, 100));
        ws.send(JSON.stringify({ type: 'input', id: targetId, data: output + '\r' }));
      }
    }, 1000);
  }
}

// WebSocket message handler
ws.onmessage = (event) => {
  const data = JSON.parse(event.data);

  switch (data.type) {
    case 'output':
      if (terminals[data.id]) {
        terminals[data.id].write(data.data);
        buffers[data.id].push(data.data);
        // Keep last 1000 items
        if (buffers[data.id].length > 1000) {
          buffers[data.id].shift();
        }
      }
      break;
    case 'completion':
      // Hook-based completion detection
      if (autoPipeline && lastCompleted !== data.id) {
        console.log(`Hook detected completion in ${data.id}, sending to ${data.id === 'a' ? 'b' : 'a'}`);
        const sourceId = data.id;

        setTimeout(() => {
          const output = extractLastOutput(buffers[sourceId]);
          const targetId = sourceId === 'a' ? 'b' : 'a';

          if (output && output.length > 10) {
            console.log(`Auto-sending ${sourceId} → ${targetId}:`, output);

            // Type the message character by character, then send Enter
            let charIndex = 0;
            const typeInterval = setInterval(() => {
              if (charIndex < output.length) {
                ws.send(JSON.stringify({ type: 'input', id: targetId, data: output[charIndex] }));
                charIndex++;
              } else {
                clearInterval(typeInterval);
                // Try multiple submission methods
                setTimeout(() => {
                  // Method 1: Carriage return
                  ws.send(JSON.stringify({ type: 'input', id: targetId, data: '\r' }));
                  // Method 2: Line feed
                  setTimeout(() => {
                    ws.send(JSON.stringify({ type: 'input', id: targetId, data: '\n' }));
                    // Update lastCompleted AFTER typing is done
                    lastCompleted = sourceId;
                    console.log(`Updated lastCompleted to ${sourceId}`);
                  }, 100);
                }, 100);
              }
            }, 10); // 10ms between each character

            // Clear buffer after sending
            buffers[sourceId] = [];
          }
        }, 1500);
      }
      break;
    case 'exit':
      const statusId = data.id === 'a' ? 'status-a' : 'status-b';
      document.getElementById(statusId).textContent = 'Exited';
      document.getElementById(statusId).classList.remove('running');
      break;
  }
};

// Auto-start function
function startTerminals() {
  ws.send(JSON.stringify({ type: 'create', id: 'a' }));
  ws.send(JSON.stringify({ type: 'create', id: 'b' }));

  document.getElementById('status-a').textContent = 'Running';
  document.getElementById('status-a').classList.add('running');
  document.getElementById('status-b').textContent = 'Running';
  document.getElementById('status-b').classList.add('running');

  // Start Claude Code in both terminals
  setTimeout(() => {
    ws.send(JSON.stringify({ type: 'input', id: 'a', data: 'claude\r' }));
    ws.send(JSON.stringify({ type: 'input', id: 'b', data: 'claude\r' }));
  }, 500);
}

// Auto-start on connection
ws.onopen = () => {
  console.log('WebSocket connected, auto-starting terminals...');
  wsReady = true;
  autoPipeline = true; // Enable auto-pipeline by default
  startTerminals();
};

// Remove ANSI escape codes
function stripAnsi(str) {
  return str.replace(/\x1b\[[0-9;]*[a-zA-Z]/g, '')  // CSI sequences
            .replace(/\x1b\][0-9;]*\x07/g, '')      // OSC sequences
            .replace(/\x1b[>=]/g, '')                // Other escapes
            .replace(/\x1b\?[0-9;]+[hl]/g, '')      // DEC private modes
            .replace(/\[[0-9;?]+[hl]/g, '')         // Leftover bracket sequences
            .replace(/\r/g, '')                      // Carriage returns
            .replace(/[\x00-\x1F\x7F-\x9F]/g, '');  // All control characters
}

// Extract last meaningful output
function extractLastOutput(buffer) {
  const text = stripAnsi(buffer.join(''));

  console.log('=== EXTRACT DEBUG ===');
  console.log('Raw text (last 1000 chars):', text.slice(-1000));
  console.log('Has ⏺:', text.includes('⏺'));

  // Find the last ⏺ position
  const lastRecordIndex = text.lastIndexOf('⏺');

  if (lastRecordIndex !== -1) {
    // Extract from ⏺ to the next status indicator or prompt
    let response = text.substring(lastRecordIndex + 1);

    // Stop at the next status indicator or prompt
    const stopPatterns = [
      /[✻✳✶✢✦·✽]/,  // Status indicators (including ·✽)
      /^>/m,         // Prompt line
      /^─+$/m        // Separator lines
    ];

    for (const pattern of stopPatterns) {
      const match = response.match(pattern);
      if (match) {
        response = response.substring(0, match.index);
        break;
      }
    }

    // Clean up
    response = response
      .replace(/\(esc to interrupt\)/g, '')
      .replace(/\? for shortcuts/g, '')
      .replace(/Thinking (on|off)/g, '')
      .replace(/ctrl-r to search/g, '')
      .replace(/toggle\)/g, '')
      .replace(/\s+/g, ' ')  // Replace multiple spaces/newlines with single space
      .trim();

    console.log('Extracted response:', response);
    console.log('===================');
    return response;
  }

  // Fallback: no ⏺ found
  console.log('No ⏺ found, using fallback');

  const lines = text.split('\n').map(line => line.trim()).filter(line => {
    if (!line) return false;
    if (line.match(/^─+$/)) return false;
    if (line.match(/^[₩─]+$/)) return false;
    if (line.match(/^[\$>❯]\s*$/)) return false;
    if (line.match(/^[✳✶✢✦✻]/)) return false;
    if (line.match(/\(esc to interrupt\)/)) return false;
    if (line.match(/Thinking (on|off)/)) return false;
    if (line.match(/ctrl-r to search/)) return false;
    if (line.match(/for shortcuts/)) return false;
    if (line.match(/toggle\)/)) return false;
    if (line.match(/^>/)) return false;
    if (line.match(/^bash-3\.2\$/)) return false;
    if (line.match(/Claude Code v/)) return false;
    if (line.match(/Sonnet 4\.5/)) return false;
    return true;
  });

  let lastResponse = '';
  for (let i = lines.length - 1; i >= 0; i--) {
    if (lines[i].length > 1) {
      lastResponse = lines[i];
      break;
    }
  }

  console.log('Extracted response:', lastResponse);
  console.log('===================');

  return lastResponse.trim();
}

// Handle window resize
window.addEventListener('resize', () => {
  fitAddons.a.fit();
  fitAddons.b.fit();
});
